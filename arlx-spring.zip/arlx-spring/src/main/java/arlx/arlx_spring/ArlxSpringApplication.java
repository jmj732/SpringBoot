package arlx.arlx_spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArlxSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArlxSpringApplication.class, args);
	}

}
